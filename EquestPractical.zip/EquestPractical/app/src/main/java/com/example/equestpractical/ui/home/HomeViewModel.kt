package com.example.equestpractical.ui.home

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.equestpractical.database.WorkoutBlock
import com.example.equestpractical.database.WorkoutDao
import com.example.equestpractical.database.WorkoutPlanData
import com.example.equestpractical.database.WorkoutPlanEntity
import com.example.equestpractical.network.NetworkResult
import com.example.equestpractical.network.Repository
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class HomeViewModel @Inject constructor(
    private val repository: Repository, var dao: WorkoutDao, application: Application
) : AndroidViewModel(application) {
    private val _workoutPlan = MutableStateFlow<NetworkResult<WorkoutPlanEntity>?>(null)
    val workoutPlanData: MutableStateFlow<NetworkResult<WorkoutPlanEntity>?> get() = _workoutPlan
    private val _workoutBlockData = MutableSharedFlow<WorkoutPlanData?>()
    val workoutBlockData: MutableSharedFlow<WorkoutPlanData?> get() = _workoutBlockData

    fun getWorkOutData() {
        viewModelScope.launch {
            repository.getWorkOutData().collect {
                workoutPlanData.emit(it)
            }
        }
    }

    suspend fun insertWorkOutData(response: WorkoutPlanEntity) {
        response.let { dao.insertWorkoutBlock(it.data) }

    }

    suspend fun addNewWorkOutData(response: WorkoutPlanData) {
        response.let { dao.insertWorkoutBlock(it) }
    }

    fun getWorkOutDataFromDatabase() {
        viewModelScope.launch {
            workoutBlockData.emit(dao.getAllWorkoutBlocks())
        }
    }

    fun deleteWorkOutData(workoutBlockId: Int) {
        viewModelScope.launch {
            dao.deleteBlockId(workoutBlockId)
        }
    }


}