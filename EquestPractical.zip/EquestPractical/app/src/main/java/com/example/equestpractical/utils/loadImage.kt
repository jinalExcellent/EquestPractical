package com.example.equestpractical.utils

import android.view.View
import android.widget.ImageView
import androidx.appcompat.widget.AppCompatImageView
import androidx.databinding.BindingAdapter
import com.bumptech.glide.Glide
import com.bumptech.glide.request.RequestOptions
import com.example.equestpractical.R

@BindingAdapter("imageUrl")
fun loadImage(
    view: View,
    imageUrl: String?
) {
    val image: AppCompatImageView = view as AppCompatImageView

    Glide.with(image.context)
        .load(imageUrl)
        .apply(
            RequestOptions()
                .placeholder(R.drawable.no_image) // Placeholder image
                .error(R.drawable.no_image) // Error image in case of loading failure
        ).into(image)

}