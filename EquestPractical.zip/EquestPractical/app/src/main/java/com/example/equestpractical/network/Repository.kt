package com.example.equestpractical.network

import com.example.equestpractical.base.BaseApiResponse
import com.example.equestpractical.database.WorkoutPlanEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.flowOn
import javax.inject.Inject

class Repository @Inject constructor(
    private val apiService: ApiService
) : BaseApiResponse() {
    suspend fun getWorkOutData(): Flow<NetworkResult<WorkoutPlanEntity>> {
        return flow<NetworkResult<WorkoutPlanEntity>> {
            emit(safeApiCall { apiService.getWorkOutData() })
        }.flowOn(Dispatchers.IO)
    }
}