package com.example.equestpractical.utils

class ApiConstants {
    companion object {
        const val BASE_URL = "https://linode25.eqserver.net/"
        const val WORKOUT_DATA = "workout-plan.json"

    }
}