package com.example.equestpractical.database

import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import com.google.gson.reflect.TypeToken

data class WorkoutPlanEntity(
    @SerializedName("message") val message: String,
    @SerializedName("success") val success: Int,
    @SerializedName("data") val data: WorkoutPlanData
)

@Entity(tableName = "workout_plan")
data class WorkoutPlanData(
    @PrimaryKey(autoGenerate = true) val workout_plan_id: Int = 0,
    @TypeConverters(WorkOutBlockConverter::class)
    var included_workout: List<WorkoutBlock>,
    @SerializedName("title") val title: String,
    @SerializedName("content") val content: String,
    @TypeConverters(StringListConverter::class)
    @SerializedName("workout_order") val workoutOrder: List<String>? = null,
    @SerializedName("total_weeks_count") val totalWeeksCount: Int,
    @TypeConverters(PlanProgressConverter::class)
    @SerializedName("current_plan_progress") val currentPlanProgress: PlanProgress
)

@Entity(tableName = "workout_block")
data class WorkoutBlock(
    @PrimaryKey(autoGenerate = true) val workout_block_id: Int = 0,
    @TypeConverters(WorkOutConverter::class)
    val workouts_list: List<Workout>,
    @SerializedName("tab_name") val tabName: String,
    var isSelectedWorkOut: Boolean = false,
    var isWorkOutAdded: Boolean = false
)

@Entity(tableName = "workout")
data class Workout(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    @SerializedName("workout_name") val workoutName: String,
    @SerializedName("user_logged_workout_id") val userLoggedWorkoutId: Int,
    @SerializedName("cover") val cover: String,
    @SerializedName("is_additional_pumpwork") val isAdditionalPumpwork: Int,
    @SerializedName("is_additional_workout") val isAdditionalWorkout: Int,
    @SerializedName("is_completed") val isCompleted: Int,
    @SerializedName("is_current_workout") val isCurrentWorkout: Int,
    @SerializedName("workout_id") val workoutId: Int,
    @SerializedName("has_previous_workouts_id") val hasPreviousWorkoutsId: Int,
    var isSelected: Boolean = false
)

data class PlanProgress(
    @SerializedName("progress") val progress: String,
    @SerializedName("id") val id: Int,
    @SerializedName("name") val name: String,
    @SerializedName("total_weeks_count") val totalWeeksCount: Int
)

class WorkOutBlockConverter {
    @TypeConverter
    fun fromJson(json: String): List<WorkoutBlock> {
        val type = object : TypeToken<List<WorkoutBlock>>() {}.type
        return Gson().fromJson(json, type)
    }

    @TypeConverter
    fun toJson(contacts: List<WorkoutBlock>): String {
        return Gson().toJson(contacts)
    }
}

class StringListConverter {
    @TypeConverter
    fun fromJson(json: String): List<String> {
        val type = object : TypeToken<List<String>>() {}.type
        return Gson().fromJson(json, type)
    }

    @TypeConverter
    fun toJson(strings: List<String>): String {
        return Gson().toJson(strings)
    }


}

class PlanProgressConverter {

    @TypeConverter
    fun fromPlanProgress(planProgress: PlanProgress): String {
        return Gson().toJson(planProgress)
    }

    @TypeConverter
    fun toPlanProgress(json: String): PlanProgress {
        val type = object : TypeToken<PlanProgress>() {}.type
        return Gson().fromJson(json, type)
    }
}

class WorkOutConverter {

    @TypeConverter
    fun fromJson(json: String): List<Workout> {
        val type = object : TypeToken<List<Workout>>() {}.type
        return Gson().fromJson(json, type)
    }

    @TypeConverter
    fun toJson(contacts: List<Workout>): String {
        return Gson().toJson(contacts)
    }
}

