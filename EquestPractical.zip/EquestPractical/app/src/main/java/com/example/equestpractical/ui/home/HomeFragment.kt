package com.example.equestpractical.ui.home

import android.annotation.SuppressLint
import android.app.Dialog
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import com.example.equestpractical.R
import com.example.equestpractical.database.WorkoutBlock
import com.example.equestpractical.database.WorkoutPlanData
import com.example.equestpractical.databinding.FragmentHomeBinding
import com.example.equestpractical.databinding.WeekDialogItemBinding
import com.example.equestpractical.network.NetworkResult
import com.google.gson.Gson
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch


@AndroidEntryPoint
class HomeFragment : Fragment() {
    var binding: FragmentHomeBinding? = null
    val homeViewModel by viewModels<HomeViewModel>()
    var workOutAdapter: WorkOutAdapter? = null
    var workOuList: ArrayList<WorkoutBlock> = arrayListOf()
    var position = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        binding = FragmentHomeBinding.inflate(inflater, container, false)
        return binding?.root
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        /*get WorkOuData from  database*/
        lifecycleScope.launch(Dispatchers.IO) {
            homeViewModel.getWorkOutDataFromDatabase()
        }
        lifecycleScope.launch(Dispatchers.Main) {
            homeViewModel.workoutBlockData.collect { workoutBlockData ->
                if (workoutBlockData != null) {
                    workOuList.clear()
                    workoutBlockData.included_workout.let { workOuList.addAll(it) }
                    binding?.tvTitle?.text = workoutBlockData.title
                    if (workoutBlockData.included_workout.isNotEmpty()) {

                        workOutAdapter =
                            WorkOutAdapter(activity,
                                workoutBlockData.included_workout,
                                onItemClick =
                                {
                                    position = it
                                    binding?.btnChangeProgram?.visibility = View.VISIBLE
                                    binding?.btnAddWorkOut?.visibility = View.VISIBLE
                                    if (it == 0) {
                                        binding?.btnStartWorkOut?.visibility = View.VISIBLE
                                    } else {
                                        binding?.btnStartWorkOut?.visibility = View.GONE
                                    }
                                    if (it == workoutBlockData.included_workout.size - 1) {
                                        binding?.btnAddNewWeek?.visibility = View.VISIBLE
                                    } else {
                                        binding?.btnAddNewWeek?.visibility = View.GONE
                                    }
                                    if (workoutBlockData.included_workout[it].isWorkOutAdded) {
                                        binding?.btnRemoveWorkOut?.visibility = View.VISIBLE
                                    } else {
                                        binding?.btnRemoveWorkOut?.visibility = View.GONE
                                    }

                                    val subAdapter =
                                        WorkOutSubAdapter(
                                            activity,
                                            workoutBlockData.included_workout[it].workouts_list
                                        )
                                    binding?.rvSubWeekData?.adapter = subAdapter
                                })
                        binding?.rvWorkOut?.adapter = workOutAdapter
                        binding?.btnAddNewWeek?.setOnClickListener {
                            showWorkOutDialog()
                        }
                        binding?.btnRemoveWorkOut?.setOnClickListener {
                            homeViewModel.deleteWorkOutData(
                                workoutBlockData.included_workout.get(
                                    position
                                ).workout_block_id
                            )
                            homeViewModel.getWorkOutDataFromDatabase()
                        }
                    }
                } else {
                    /*Api call of WorkOuData*/
                    homeViewModel.getWorkOutData()
                }

            }
        }
        lifecycleScope.launch(Dispatchers.Main) {
            homeViewModel.workoutPlanData.collect { response ->
                when (response) {
                    is NetworkResult.Success -> {
                        response.data?.let { homeViewModel.insertWorkOutData(response.data) }
                        homeViewModel.getWorkOutDataFromDatabase()
                    }

                    is NetworkResult.Error -> {
                        // show error message
                    }

                    is NetworkResult.Loading -> {
                        // show a progress bar
                    }

                    else -> {}
                }

            }
        }

    }

    private fun showWorkOutDialog() {
        val dialog = Dialog(requireActivity())
        dialog.setCancelable(false)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
        val binding = WeekDialogItemBinding.inflate(LayoutInflater.from(activity))
        binding.ivClose.setOnClickListener {
            dialog.dismiss()
        }
        dialog.setTitle(getString(R.string.select_week_to_repeat))
        val workOutDialogAdapter =
            WorkOutDialogAdapter(activity, workOuList, onItemClick = { index ->
                val arrayOfWork: ArrayList<WorkoutBlock> = arrayListOf()

                workOuList.forEachIndexed { index, modelOfWork ->
                    arrayOfWork.add(modelOfWork.copy())
                }
                arrayOfWork.add(
                    workOuList.get(index = index)
                        .copy(
                            tabName = "Week ${workOuList.size + 1}",
                            isWorkOutAdded = true,
                            workout_block_id = workOuList.size + 1
                        )
                )
                lifecycleScope.launch {
                    val modelOfWorkoutPlanData = homeViewModel.dao.getAllWorkoutBlocks()
                    modelOfWorkoutPlanData.included_workout = arrayOfWork
                    homeViewModel.addNewWorkOutData(modelOfWorkoutPlanData)
                    homeViewModel.getWorkOutDataFromDatabase()
                }

                dialog.dismiss()
            })

        binding.rvSelectedWorkOut.adapter = workOutDialogAdapter

        dialog.setContentView(binding.root)

        dialog.show();

    }

}