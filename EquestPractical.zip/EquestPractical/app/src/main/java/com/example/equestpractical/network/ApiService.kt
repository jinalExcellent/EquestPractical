package com.example.equestpractical.network


import com.example.equestpractical.database.WorkoutPlanEntity
import com.example.equestpractical.utils.ApiConstants
import retrofit2.Response
import retrofit2.http.GET

interface ApiService {
    @GET(ApiConstants.WORKOUT_DATA)
    suspend fun getWorkOutData(): Response<WorkoutPlanEntity>


}