package com.example.equestpractical.ui.home

import android.annotation.SuppressLint
import android.graphics.Typeface
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.example.equestpractical.R
import com.example.equestpractical.database.WorkoutBlock
import com.example.equestpractical.databinding.WeekItemBinding

class WorkOutAdapter(
    var activity: FragmentActivity?,
    var includedWorkout: List<WorkoutBlock>?,
    private val onItemClick: (Int) -> Unit
) :
    RecyclerView.Adapter<WorkOutAdapter.MyViewHolder>() {
    lateinit var binding: WeekItemBinding
    var selectedPos=0

    class MyViewHolder(private val binding: WeekItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(workOutBlock: WorkoutBlock) {
            binding.workOutBlock = workOutBlock
            binding.executePendingBindings()
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): WorkOutAdapter.MyViewHolder {
        binding =
            WeekItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onBindViewHolder(holder: WorkOutAdapter.MyViewHolder, position: Int) {
        holder.bind(includedWorkout!![position])
        holder.setIsRecyclable(false)
        if(selectedPos==position)
        {
            onItemClick(position)
            binding.tvWeekName.background = ContextCompat.getDrawable(activity!!, R.drawable.bg_selected_btn)
            binding.tvWeekName.setTypeface(null,Typeface.BOLD)
        }else
        {
            binding.tvWeekName.background = ContextCompat.getDrawable(activity!!, R.drawable.bg_unselected_btn)
            binding.tvWeekName.setTypeface(null,Typeface.NORMAL)
        }
        holder.itemView.setOnClickListener {
            selectedPos=position
            notifyDataSetChanged()

        }
    }

    override fun getItemCount(): Int {
        return includedWorkout?.size!!
    }
}