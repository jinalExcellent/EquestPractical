package com.example.equestpractical.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters

@Database(entities = [WorkoutPlanData::class,WorkoutBlock::class,Workout::class], version = 1)
@TypeConverters(
    WorkOutBlockConverter::class,
    StringListConverter::class,
    PlanProgressConverter::class,WorkOutConverter::class
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun workoutDao(): WorkoutDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null


        fun getDatabase(context: Context): AppDatabase {
            // if the INSTANCE is not null, then return it,
            // if it is, then create the database
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "work_out_database"
                ).build()
                INSTANCE = instance
                // return instance
                instance
            }
        }
    }

}