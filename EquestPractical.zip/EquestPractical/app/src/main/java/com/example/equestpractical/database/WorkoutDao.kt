package com.example.equestpractical.database

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction

@Dao
interface WorkoutDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertWorkoutBlock(workoutBlock: WorkoutPlanData)

    @Query("SELECT * FROM workout_plan")
    suspend fun getAllWorkoutBlocks(): WorkoutPlanData


    @Query("DELETE FROM workout_block WHERE  workout_block_id= :workoutBlockIds")
    suspend fun deleteBlockId(workoutBlockIds: Int)
}
