package com.example.equestpractical.ui.home

import android.annotation.SuppressLint
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.example.equestpractical.database.WorkoutBlock
import com.example.equestpractical.databinding.WeekDialogItemBinding
import com.example.equestpractical.databinding.WeekDialogSubItemBinding
import com.example.equestpractical.databinding.WeekSubItemBinding

class WorkOutDialogAdapter(
    var activity: FragmentActivity?,
    var includedWorkout: List<WorkoutBlock>?,
    private val onItemClick: (Int) -> Unit
) :
    RecyclerView.Adapter<WorkOutDialogAdapter.MyViewHolder>() {
    lateinit var binding: WeekDialogSubItemBinding

    class MyViewHolder(private val binding: WeekDialogSubItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(workOutBlock: WorkoutBlock) {
            binding.workOutBlock = workOutBlock
            binding.executePendingBindings()
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): WorkOutDialogAdapter.MyViewHolder {
        binding =
            WeekDialogSubItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    @SuppressLint("NotifyDataSetChanged")
    override fun onBindViewHolder(holder: WorkOutDialogAdapter.MyViewHolder, position: Int) {
        holder.bind(includedWorkout!![position])
        if (position == includedWorkout!!.size - 1) {
            binding.weekView.visibility = View.GONE
        }
        holder.itemView.setOnClickListener {
            onItemClick.invoke(position)

        }


    }

    override fun getItemCount(): Int {
        return includedWorkout?.size!!
    }
}