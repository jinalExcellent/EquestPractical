package com.example.equestpractical.ui.home

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.fragment.app.FragmentActivity
import androidx.recyclerview.widget.RecyclerView
import com.example.equestpractical.database.Workout
import com.example.equestpractical.databinding.WeekSubItemBinding

class WorkOutSubAdapter(activity: FragmentActivity?, var includedWorkout: List<Workout>) :
    RecyclerView.Adapter<WorkOutSubAdapter.MyViewHolder>() {
    class MyViewHolder(private val binding: WeekSubItemBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(workOutBlock: Workout) {
            binding.workOutBlock = workOutBlock
            binding.executePendingBindings()
        }
    }

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): WorkOutSubAdapter.MyViewHolder {
        val binding =
            WeekSubItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: WorkOutSubAdapter.MyViewHolder, position: Int) {
        holder.bind(includedWorkout[position])
    }

    override fun getItemCount(): Int {
        return includedWorkout.size
    }
}